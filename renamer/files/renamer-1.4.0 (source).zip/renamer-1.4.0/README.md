# renamer
Renamer is a lightweight, mass file renaming utility based on the Qt framework. It's designed to be very simple yet robust with it's drag-n-drop interface and use of regular expressions. Binary executables for Linux (both 32 and 64-bit) and Windows are available, as well as Renamer's source code.

**Main Features**
* Cross-Platform
* Drag-n-Drop interface
* Regex search and replace
* Literal search and replace
* Renames files and folders
